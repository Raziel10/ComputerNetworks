
class Simulator{
    float lambda;
    float T;
public:
    Simulator();
    void run();    
};