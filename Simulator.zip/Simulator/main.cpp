#include <iostream>
#include "simulator.h"

using namespace std;

int main(void){
    Simulator* s = new Simulator();
    s->run();
}
